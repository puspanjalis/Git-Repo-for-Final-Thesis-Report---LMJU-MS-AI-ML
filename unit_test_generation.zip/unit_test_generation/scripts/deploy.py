# standard imports
import argparse
import json


import argparse
import json
import argparse
from ml_service.util.azure.aml import AzureResources as AR
from azureml.core import Run, Workspace
from azureml.core.run import _OfflineRun
import os


class Script:
    def __init__(self, script_args=None) -> None:
        self.run = Run.get_context()
        self.ws = (
            Workspace.from_config()
            if isinstance(self.run, _OfflineRun)
            else self.run.experiment.workspace
        )
        self.AR = AR(ws=self.ws)
        self.args = script_args

        self.pipeline_config = json.loads(self.args.pipeline_config)
        self.keyvault_keys_config = self.pipeline_config["keyvault_keys"]
        pass

    def run_script(self):
        default_keyvault = self.ws.get_default_keyvault()

        gpt_35_turbo_api_key = default_keyvault.get_secret(
            self.keyvault_keys_config["gpt_35_turbo_api_key"])
        gpt_35_turbo_url = default_keyvault.get_secret(
            self.keyvault_keys_config["gpt_35_turbo_url"])


        gpt_4_api_key = default_keyvault.get_secret(
            self.keyvault_keys_config["gpt_4_api_key"])
        gpt_4_url = default_keyvault.get_secret(
            self.keyvault_keys_config["gpt_4_url"])

        log_connection_string = default_keyvault.get_secret(
            self.keyvault_keys_config["log_connection_string"])
        
        env_variables = {
            'TEST_ASSIST_GPT_35_TURBO_API_KEY': gpt_35_turbo_api_key,
            'TEST_ASSIST_GPT_35_TURBO_URL': gpt_35_turbo_url,
            'TEST_ASSIST_GPT_4_API_KEY': gpt_4_api_key,
            'TEST_ASSIST_GPT_4_URL': gpt_4_url,
            'TEST_ASSIST_LOG_CONNECTION_STRING': log_connection_string

        }

        pipeline_config = json.loads(self.args.pipeline_config)

        # CREATE INFERENCE CONFIG
        entry_script_path = "test_assist/unit_test_generation/scripts/entry_script_no_ullm.py"
        inference_config = self.AR.get_inference_config(
            environment_name="test_assist_env",
            entry_script_path=entry_script_path,
            environment_variables_dict=env_variables
        )

        # GETTING MODEL
        model = self.AR.get_model("test-assist-code-search-faiss-index-test")
        code_model = self.AR.get_model("test-assist-codetocode-code-model")

        aks_target = self.AR.get_compute_target(
            cluster_name=pipeline_config["inference_cluster"]
        )

        # DEPLOYING ENDPOINT TO AKS

        self.AR.deploy_model_to_AKS(
            endpoint_name="unit-test-assist-no-ullm",
            model=model,
            code_model=code_model,
            inference_config=inference_config,
            aks_target=aks_target,
            traffic_percentile=0,
            max_request_wait_time=300000,
            scoring_timeout_ms=300000,
            timeout_seconds=240,
            period_seconds=15,
            initial_delay_seconds=480,
            failure_threshold=5,
            replica_max_concurrent_requests=2,
            num_replicas=3,
            cpu_cores=1,
            memory_gb=2,
            auth_enabled=True,
            enable_app_insights=True
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--pipeline_config", help="pipeline configurations")

    args = parser.parse_args()

    script_obj = Script(script_args=args)

    script_obj.run_script()

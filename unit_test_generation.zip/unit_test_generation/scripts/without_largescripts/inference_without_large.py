# standard imports
import joblib
import os
import re
import warnings
import json
import time
import argparse
import openai
import tiktoken
import langchain
from langchain.schema import Document
from langchain.callbacks import get_openai_callback
from langchain.chains.question_answering import load_qa_chain
from langchain.chat_models import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import random
# external imports
import faiss
from datetime import datetime
from sentence_transformers import SentenceTransformer


class Inference:

    def __init__(self, model_path):
        self.model_path = model_path
        self.embeddings = SentenceTransformerEmbeddings(
            model_name="multi-qa-MiniLM-L6-cos-v1")
        self.db = FAISS.load_local(self.model_path, self.embeddings)
        openai.api_key = os.environ.get('TEST_ASSIST_GPT_35_TURBO_API_KEY')
        openai.api_base = os.environ.get('TEST_ASSIST_GPT_35_TURBO_URL')
        openai.api_type = "azure"
        openai.api_version = "2023-05-15"

        self.llm_gpt35_4k = AzureChatOpenAI(
            openai_api_base=openai.api_base,
            openai_api_version=openai.api_version,
            deployment_name='gpt-35-turbo',
            openai_api_key=openai.api_key,
            openai_api_type=openai.api_type,
            temperature=0, model_kwargs={"top_p": 0.1})

        self.llm_gpt35_16k = AzureChatOpenAI(
            openai_api_base=openai.api_base,
            openai_api_version=openai.api_version,
            deployment_name='gpt-35-turbo-16k',
            openai_api_key=openai.api_key,
            openai_api_type=openai.api_type,
            temperature=0, model_kwargs={"top_p": 0.1})

        openai.api_key = os.environ.get('TEST_ASSIST_GPT_4_API_KEY')
        openai.api_base = os.environ.get('TEST_ASSIST_GPT_4_URL')
        openai.api_type = "azure"
        openai.api_version = "2023-05-15"

        self.llm_gpt4_32k = AzureChatOpenAI(
            openai_api_base=openai.api_base,
            openai_api_version=openai.api_version,
            deployment_name='gpt-4-32k',
            openai_api_key=openai.api_key,
            openai_api_type=openai.api_type,
            temperature=0, model_kwargs={"top_p": 0.1})

    def num_tokens_from_string(self, string: str, encoding_name: str) -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

    def code_clean(self, code):
        code = re.sub(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b',
            f"{{{'email'}}}",
            code)
        code = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', f"{{{'phone'}}}", code)
        code = re.sub(r'\b\d{3}[-]?\d{2}[-]?\d{4}\b', f"{{{'ssn '}}}", code)
        code = re.sub(r'\b\d{3}[ ]?\d{2}[ ]?\d{4}\b', f"{{{'ssn'}}}", code)
        code = re.sub(
            r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            f"{{{'ip address'}}}",
            code)
        code = re.sub(r'//.*', '', code)
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        return code

    def restructure_document_object(self, matching_docs):
        filtered_documents = []
        for row in matching_docs:
            input_doc_content = row.page_content + \
                "\n\n" + row.metadata.get('unit_test_cases')
            document_obj = Document(page_content=input_doc_content)
            filtered_documents.append(document_obj)
        return filtered_documents

    def gpt35turbo_langchain_generate_310(self, code):

        start_time = datetime.now()
        response = None
        total_cost = ""
        tokens_count = ""
        model_used = ""
        error = ""
        error_type = ""
        azure_start_time = ""
        azure_end_time = ""
        if len(code) <= 5:
            response = None
            error = "length of source code is too short to generate a response"
            error_type = "not_enough_tokens"

        elif len(code) > 5:

            code = self.code_clean(code)
            prompt = '''
            Task:
            write unit test cases in Jasmine Framework for below servicenow script, create various test scenarios using multiple data points

            Instructions:
            - understand the code snippet below and write unit test cases
            - consider every scenario for unit testing
            - only write code
            - no comments and explanations for the written code

            code snippet:
            ####

            {0}

            ####

            Example output format:
            //comments
            <code>
            </code>
            '''.format(code)

            input_prompt_size = self.num_tokens_from_string(
                prompt, "cl100k_base")
            print("input prompt size: " + str(input_prompt_size))

            if input_prompt_size < 1500:
                model_used = 'gpt-35-turbo'
                llm = self.llm_gpt35_4k

                retriever = self.db.as_retriever(
                    search_type="similarity_score_threshold", search_kwargs={
                        "score_threshold": 0.5, "k": 1})
                matching_docs = retriever.get_relevant_documents(code)

                # if len(matching_docs) == 0:
                #    retriever = self.db.as_retriever(search_type="similarity_score_threshold", search_kwargs={"score_threshold": 0.5,"k": 1})
                #    matching_docs = retriever.get_relevant_documents(code)

            elif input_prompt_size >= 1500 and input_prompt_size < 8000:
                model_used = 'gpt-35-turbo-16k'
                llm = self.llm_gpt35_16k

                retriever = self.db.as_retriever(
                    search_type="similarity_score_threshold", search_kwargs={
                        "score_threshold": 0.75, "k": 1})
                matching_docs = retriever.get_relevant_documents(code)

            elif input_prompt_size >= 8000 and input_prompt_size < 16000:
                model_used = 'gpt-4-32k'
                llm = self.llm_gpt4_32k

                retriever = self.db.as_retriever(
                    search_type="similarity_score_threshold", search_kwargs={
                        "score_threshold": 0.5, "k": 1})
                matching_docs = retriever.get_relevant_documents(code)

            else:
                model_used = 'gpt-4-32k'
                llm = self.llm_gpt4_32k
                matching_docs = []

            # retriever = self.db.as_retriever(search_type="similarity_score_threshold", search_kwargs={"score_threshold": 0.75,"k": 1})
            # matching_docs = retriever.get_relevant_documents(code)

            azure_start_time = datetime.now()
            # if len(matching_docs) == 0:
            #     retriever = self.db.as_retriever(search_type="similarity_score_threshold", search_kwargs={"score_threshold": 0.5,"k": 1})
            #     matching_docs = retriever.get_relevant_documents(code)

            if len(matching_docs) == 0:
                with get_openai_callback() as cb:
                    response = llm(messages=[HumanMessage(content=prompt)])
                    response = response.content
                    tokens_count = cb.total_tokens
                    total_cost = cb.total_cost
            else:
                with get_openai_callback() as cb:
                    matching_docs = self.restructure_document_object(
                        matching_docs)
                    chain = load_qa_chain(llm, chain_type="stuff")
                    response = chain.run(
                        input_documents=matching_docs, question=prompt)
                    tokens_count = cb.total_tokens
                    total_cost = cb.total_cost
            azure_end_time = datetime.now()
        # tokens_count = input_prompt_size + num_tokens_from_string(response,"cl100k_base")

        end_time = datetime.now()
        azure_time_taken = round(
            (azure_end_time - azure_start_time).total_seconds(),
            2)  # type: ignore
        time_taken = round((end_time - start_time).total_seconds(), 2)
        return response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken

    def gpt35turbo_dummy(self, code):
        start_time = datetime.now()
        response = '''
        //This is a dummy response
        describe('Unit Testing for getTableId', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the unique value of the table record when the table name is valid', function() {
                var tableName = 'sys_user';
                var result = unitTestGenrationUtil.getTableId(tableName);
                var expectedResult = '1234567890';
                expect(result).toEqual(expectedResult);
            });

            it('should return false when the table name is invalid', function() {
                var tableName = 'invalid_table';
                var result = unitTestGenrationUtil.getTableId(tableName);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for createUnitTestRecord', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return false when scriptIncludeObj, sourceCode, and documentRef are all null', function() {
                var scriptIncludeObj = null;
                var sourceCode = null;
                var documentRef = null;
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });

            it('should create a unit test record when scriptIncludeObj is not null', function() {
                var scriptIncludeObj = new GlideRecord('sys_script_include');
                scriptIncludeObj.get('1234567890');
                var sourceCode = null;
                var documentRef = null;
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                expect(result).toBeTruthy();
            });

            it('should create a unit test record when sourceCode is not null', function() {
                var scriptIncludeObj = null;
                var sourceCode = 'function test() { return true; }';
                var documentRef = '1234567890';
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                expect(result).toBeTruthy();
            });
        });

        describe('Unit Testing for extractFunctionLineNumbers', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return an array of function objects with startLine and endLine properties', function() {
                var code = 'function test1() {\n    return true;\n}\n\nfunction test2() {\n    return false;\n}';
                var result = unitTestGenrationUtil.extractFunctionLineNumbers(code);
                var expectedResult = [
                    { name: 'test1', startLine: 1, endLine: 3 },
                    { name: 'test2', startLine: 5, endLine: 7 }
                ];
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getFunctionStartLine', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the line number of the start of the function', function() {
                var lines = [
                    'function test1() {',
                    '    return true;',
                    '}',
                    '',
                    'function test2() {',
                    '    return false;',
                    '}'
                ];
                var index = 5;
                var result = unitTestGenrationUtil.getFunctionStartLine(lines, index);
                var expectedResult = 5;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getDeltaSourceCode', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the delta source code based on the uncovered lines', function() {
                var scriptIncludeObj = new GlideRecord('sys_script_include');
                scriptIncludeObj.get('1234567890');
                var result = unitTestGenrationUtil.getDeltaSourceCode(scriptIncludeObj);
                expect(result).toBeTruthy();
            });
        });

        describe('Unit Testing for isInRange', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return true if the number is within the range of any object in the jsonArray', function() {
                var jsonArray = [
                    { startLine: 1, endLine: 3 },
                    { startLine: 5, endLine: 7 }
                ];
                var number = 2;
                var result = unitTestGenrationUtil.isInRange(jsonArray, number);
                var expectedResult = true;
                expect(result).toEqual(expectedResult);
            });

            it('should return false if the number is not within the range of any object in the jsonArray', function() {
                var jsonArray = [
                    { startLine: 1, endLine: 3 },
                    { startLine: 5, endLine: 7 }
                ];
                var number = 4;
                var result = unitTestGenrationUtil.isInRange(jsonArray, number);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getExecutableLineNumbers', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return a comma-separated string of line numbers that are executable', function() {
                var code = 'function test1() {\n    return true;\n}\n\nfunction test2() {\n    return false;\n}';
                var result = unitTestGenrationUtil.getExecutableLineNumbers(code);
                var expectedResult = '1,2,4,5,6,7';
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getCodeCoverageRecord', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the latest code coverage record for the given scriptIncludeId', function() {
                var scriptIncludeId = '1234567890';
                var result = unitTestGenrationUtil.getCodeCoverageRecord(scriptIncludeId);
                expect(result).toBeTruthy();
            });
        });
        '''
        end_time = datetime.now()
        time_taken = round((end_time - start_time).total_seconds(), 2)
        azure_time_taken = '0'
        tokens_count = '2346'
        total_cost = '0.00000001'
        model_used = 'gpt-35-turbo-dummy'
        error = ""
        error_type = ""
        return response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken

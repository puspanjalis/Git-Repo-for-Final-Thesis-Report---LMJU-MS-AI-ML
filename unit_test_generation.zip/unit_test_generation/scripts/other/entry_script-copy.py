
###########################

from test_assist.unit_test_generation.scripts.inference_ullm import Inference
import time
from opencensus.ext.azure.log_exporter import AzureLogHandler
import json
import os
import logging
import sys
import requests
import urllib
import io
import json
import openai

# import requests,urllib,
# import tiktoken
# import langchain
# from langchain.chains.question_answering import load_qa_chain
# from langchain.chat_models import AzureChatOpenAI
# from langchain.prompts import ChatPromptTemplate
# from langchain.schema import HumanMessage
# from langchain.chains import RetrievalQA
# from langchain.embeddings.openai import OpenAIEmbeddings
# from langchain.text_splitter import CharacterTextSplitter
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain.embeddings import SentenceTransformerEmbeddings

# from langchain.vectorstores import FAISS
from azureml.core.model import Model
from azureml.core import Workspace

# import pandas as pd
import warnings
from datetime import datetime

warnings.filterwarnings('ignore')
# from opencensus.ext.azure.log_exporter import AzureEventHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())
logger.addHandler(
    AzureLogHandler(
        connection_string=os.environ.get('TEST_ASSIST_LOG_CONNECTION_STRING')))
logger.setLevel(logging.DEBUG)


logging.basicConfig(level=logging.DEBUG)

            # 'AZURE_WORKSPACE_NAME': azure_workspace_name,
            # 'AZURE_WORKSPACE_SUBSCRIPTION_ID': azure_workspace_subscription_id,
            # 'AZURE_WORKSPACE_RESOURCE_GROUP': azure_workspace_resource_group

def init():
    global model_name
    model_name = "test-assist-code-search-faiss-index-test"



    global model
    #faiss_model = Model(ws,name=model_name)
    #faiss_model=model.download(exist_ok = True)

    # fetch_model = Model(workspace=workspace, name=model_name)
    
    model_path = Model.get_model_path(model_name=model_name)

    global model
    model = Inference(model_path)


def run(data: str):
    logger.info("Input data: \n " + str(data))
    try:
        # input parameter={"code:"glide_code"}
        if data != "{}":
            req_body = json.loads(data)
            code = req_body['code']
            code = code.replace("\r\n\r\n", "\n \n").replace("\r\n", "\n").replace("\\n", "\n").replace("\n\n","\n \n")
            logger.info("Input Code: \n" + str(code))
            openai_flag = req_body['openai_flag']

            code_token_count = model.num_tokens_from_string(code,"cl100k_base")

            if openai_flag == 'True' and code_token_count <= 6000:
                response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken = model.gpt35turbo_langchain_generate(
                    code)
            elif openai_flag == 'True' and code_token_count > 6000:
                response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken = model.gpt35turbo_langchain_generate(
                    code)    
            elif openai_flag == 'False':
                response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken = model.gpt35turbo_dummy(
                    code)

            # post processing
            response = response.replace("```javascript", "")
            response = response.replace("```", "")

            if response is not None:
                output = {
                    "result": response,
                    "time_taken": time_taken,
                    "azure_time_taken": azure_time_taken,
                    "total_tokens_count": tokens_count,
                    "self_calculated_tokens_count":self_calculated_token_size,
                    "total_cost": total_cost,
                    "model_used": model_used,
                    "endpoint_name": "test-assist-prod",
                    "status": "success"}
                logger.info(
                    "Logging Test Assist Response Status", extra={
                        "custom_dimensions": output})
                return output
            else:
                output = {
                    "result": "Unable to generate response",
                    "status": "failed",
                    "error": error,
                    "error_type": error_type}
                logger.info(
                    "Logging Test Assist Response Status", extra={
                        "custom_dimensions": output})
                return output
        else:
            output = {
                "result": "Unable to generate response",
                "status": "failed",
                "error": "empty json error",
                "error_type": "generic_errors"}
            logger.info(
                "Logging Test Assist Response Status 6", extra={
                    "custom_dimensions": output})
            return_output = json.dumps(output)
            return return_output
    except openai.APIConnectionError as e:
        # Handle timeout error, e.g. retry or log
        error = "OpenAI API Connection Error could not be established: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.APITimeoutError as e:
        # Handle API error, e.g. retry or log
        error = "OpenAI API returned an API Timeout Error: " + str(e)
        error_type = "timeout_error"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 1",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.AuthenticationError as e:
        # Handle API error, e.g. retry or log
        error = "OpenAI API returned an Authentication Error: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 2",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.BadRequestError as e:
        # Handle connection error, e.g. check network or log
        error = "OpenAI API request failed to Bad Request: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 3",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.ConflictError as e:
        # Handle invalid request error, e.g. validate parameters or log
        error = "OpenAI API request has a conflict: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 4",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.ConflictError as e:
        # Handle invalid request error, e.g. validate parameters or log
        error = "OpenAI API request has a conflict: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 5",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.InternalServerError as e:
        # Handle authentication error, e.g. check credentials or log
        error = "OpenAI API request had an internal server error: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 6",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.NotFoundError as e:
        # Handle permission error, e.g. check scope or log
        error = "OpenAI API request couldn't be processed: " + str(e)
        error_type = "max_token_size_exceeded"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 7",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.PermissionDeniedError as e:

        error = "OpenAI API request couldn't be processed, permission denied: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 8",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.RateLimitError as e:
        # Handle rate limit error, e.g. wait or log
        error = "OpenAI API request couldn't be processed, Rate Limit reached: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 9",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except openai.UnprocessableEntityError as e:
        # Handle rate limit error, e.g. wait or log
        error = "OpenAI API request couldn't be processed, Unprocessable Entity Error: " + str(e)
        error_type = "generic_errors"
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 10",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output
    except Exception as e:
        error = str(e)
        error_type = "generic_errors"
        if "Error code: 404" in error:
            error_type = "max_token_size_exceeded"
        
        output = {
            "result": "Unable to generate response",
            "status": "failed",
            "error": error,
            "error_type": error_type}
        logger.info("Logging Test Assist Response Status 6",
                    extra={"custom_dimensions": output})
        return_output = json.dumps(output)
        return return_output

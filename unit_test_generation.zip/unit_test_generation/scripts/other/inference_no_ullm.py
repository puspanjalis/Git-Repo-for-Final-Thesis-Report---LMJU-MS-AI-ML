# standard imports
import urllib.request
import logging
import ssl
from urllib.request import quote,unquote
import requests
import joblib
import os
import re
import warnings
import json
import time
import argparse
import numpy as np
import openai
from openai import AzureOpenAI
import tiktoken
import langchain

import pandas as pd
import concurrent.futures
from langchain.schema import Document
from langchain.callbacks import get_openai_callback
from langchain.chains.question_answering import load_qa_chain
from langchain.chat_models import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import random
# external imports
import faiss
from datetime import datetime
from sentence_transformers import SentenceTransformer
from azureml.core.model import Model
from azureml.core import Workspace
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_core.prompts.prompt import PromptTemplate

class Inference:

    def __init__(self, model):
        self.model_path = model
        self.embeddings = SentenceTransformerEmbeddings(
            model_name="multi-qa-MiniLM-L6-cos-v1")
        self.db = FAISS.load_local(self.model_path, self.embeddings,allow_dangerous_deserialization=True)

        self.api_key_16k = os.environ.get('ULLM_TEST_ASSIST_GPT_35_TURBO_API_KEY')
        self.api_key = os.environ.get('ULLM_TEST_ASSIST_GPT_35_TURBO_16K_API_KEY')
        self.url = os.environ.get('ULLM_TEST_ASSIST_GPT_35_TURBO_URL')

        openai.api_key = os.environ.get('TEST_ASSIST_GPT_35_TURBO_API_KEY')
        openai.api_base = os.environ.get('TEST_ASSIST_GPT_35_TURBO_URL')
        openai.api_type = "azure"
        openai.api_version = "2023-05-15"

        self.client = AzureOpenAI(api_version=openai.api_version,azure_endpoint=openai.api_base,api_key=openai.api_key) 

        self.llm_gpt35_4k = AzureChatOpenAI(
            openai_api_base=openai.api_base,
            openai_api_version=openai.api_version,
            deployment_name='gpt-35-turbo',
            openai_api_key=openai.api_key,
            openai_api_type=openai.api_type,
            temperature=0, model_kwargs={"top_p": 0.1})

        self.llm_gpt35_16k = AzureChatOpenAI(
            openai_api_base=openai.api_base,
            openai_api_version=openai.api_version,
            deployment_name='gpt-35-turbo-16k',
            openai_api_key=openai.api_key,
            openai_api_type=openai.api_type,
            temperature=0, model_kwargs={"top_p": 0.1})

    def restructure_document_object(self, matching_docs):
        filtered_documents = []
        for row in matching_docs:
            input_doc_content = row.page_content + \
                "\n\n" + row.metadata.get('unit_test_cases')
            input_code = self.code_clean(row.page_content)
            output_code= self.code_clean(row.metadata.get('unit_test_cases'))
            document_obj = {"input": input_code , "output":output_code}
            filtered_documents.append(document_obj)
        return filtered_documents 

    def few_shot_prompting_template(self,examples):
        example_template = '''
        Input:
            Task:
            write unit test cases in Jasmine Framework for below servicenow script, create various test scenarios using multiple data points

            Instructions:
            - understand the code snippet below and write unit test cases
            - consider every scenario for unit testing
            - only write code
            - no comments and explanations for the written code

            code snippet:
            ####

            "{input}"

            ####

            Expected Output Format:
            // Test case: Testing....
            <code>
            .
            .

        Output:
            {output}
        '''
        #print(type(examples[0]))
        
        examples_retreived = ""
        for i in examples:
            temp = example_template.format(input=i.get('input'),output=i.get('output')) + "\n\n"
            examples_retreived = examples_retreived + temp
            

        return examples_retreived
    
    def gpt_35_turbo_chat_completion(self,value):
        #self.allowSelfSignedHttps(True)
        #print(value)
        # value = [{"role": "user", "content": quote(prompt)}]
        # value_unquote = [{"role": "user", "content": prompt}]
        turbo_data = {
            'messages': value,
            'temperature': 0,
            'top_p': 0.1
        }
        #print(str(turbo_data))
        # turbo_data_unquote = {
        #     "messages": value_unquote,
        #     'temperature': 0,
        #     'top_p': 0.1
        # }
        # print(str(turbo_data_unquote))
        #print(str(turbo_data))
        turbo_body = str.encode(json.dumps(turbo_data))
        url = self.url
        api_key = self.api_key
        if not api_key:
            raise Exception("A key should be provided to invoke the endpoint")

        headers = {'Content-Type': 'application/json','api-key': api_key}

        #req = urllib.request.Request(url, turbo_body, headers)
        result =""
        prompt_response=""
        tokens_count = 0
        total_cost = 0.0
        model =""
        status =""
        status_code = 0
        error_message=""

        try:
            #req = urllib.request.Request(url, turbo_body, headers)
            response = requests.post(url=url,headers=headers,data=turbo_body)
            status_code = response.status_code
            response_json = response.json()
            #response_json = json.loads(response.text)
            
            #print(response_json)
            prompt_response = response_json['choices'][0]['message']['content']
            print(prompt_response)
            tokens_count = response_json['usage']['total_tokens']
            total_cost = (int(response_json['usage']['prompt_tokens'])/1000)*0.0005 + (int(response_json['usage']['completion_tokens'])/1000)*0.0015
            total_cost = round(total_cost,4)
            model = response_json['model']
            status = "success"

        except requests.exceptions.RequestException as error:  # This is the correct syntax
            
            status_code = error.errno
            status = "failed"
            print(error)
            raise(error)

        return prompt_response,tokens_count,total_cost,model,status,status_code,error_message


    def gpt_35_turbo_16k_chat_completion(self,value):
        #print(value)
        turbo_data = {
            'messages': value,
            'temperature': 0,
            'top_p': 0.1
        }
        #print(str(turbo_data))
        turbo_body = str.encode(json.dumps(turbo_data))
        url = self.url
        api_key = self.api_key_16k
        if not api_key:
            raise Exception("A key should be provided to invoke the endpoint")

        headers = {'Content-Type': 'application/json','api-key': api_key}

        result =""
        prompt_response=""
        tokens_count = 0
        total_cost = 0.0
        model =""
        status =""
        status_code = 0
        error_message=""

        try:
            start=datetime.now()

            #req = urllib.request.Request(url, turbo_body, headers)
            response = requests.post(url=url,headers=headers,data=turbo_body)
            status_code = response.status_code
            #response_json = json.loads(response.text)
            
            response_json = response.json()
            #print(response_json)
            prompt_response = response_json['choices'][0]['message']['content']
            print(prompt_response)
            tokens_count = response_json['usage']['total_tokens']
            total_cost = (int(response_json['usage']['prompt_tokens'])/1000)*0.0005 + (int(response_json['usage']['completion_tokens'])/1000)*0.0015
            total_cost = round(total_cost,4)
            model = response_json['model']
            status = "success"
            end=datetime.now()
            time_taken = round((end - start).total_seconds(),2)
            print(str(time_taken))
            
        except requests.exceptions.RequestException as error:  # This is the correct syntax
            end=datetime.now()
            time_taken = round((end - start).total_seconds(),2)
            print(str(time_taken))
            status_code = error.errno
            status = "failed"
            print(error)
            raise(error)

        return prompt_response,tokens_count,total_cost,model,status,status_code,error_message

    def num_tokens_from_string(self, string: str, encoding_name: str) -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

    def code_clean(self,code):
        code = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b', f"{{{'email'}}}", code)
        code = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', f"{{{'phone'}}}", code)
        code = re.sub(r'\b\d{3}[-]?\d{2}[-]?\d{4}\b', f"{{{'ssn '}}}", code)
        code = re.sub(r'\b\d{3}[ ]?\d{2}[ ]?\d{4}\b', f"{{{'ssn'}}}", code)
        code = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', f"{{{'ip address'}}}", code)
        code = re.sub(r'//.*', '', code)
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        return code

    def parallel_api_call(self,final_list):
        # Define the number of threads (adjust as needed)
        num_threads = len(final_list)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            print("parallel call started check point")
            # Submit tasks to the executor
            futures = [executor.submit(self.gpt35turbo_langchain_generate, item) for item in final_list]
        
            # Wait for all tasks to complete
            concurrent.futures.wait(futures)
            print("parallel calls completed check point")
            # Get results
            print("list comprehension started check point")
            results = [future.result() for future in futures]
            print("results: \n" + str(results))
            response = '\n'.join([x[0] for x in results])
            #response = '\n'.join([tuple(xi for xi in x[0] if xi is not None) for x in results])
            time_taken = max([x[1] for x in results])
            token_count = sum([x[2] for x in results])
            total_cost = sum([x[3] for x in results])
            model_used = ",".join(list(set([x[4] for x in results])))
            error = ",".join(list(set([x[5] for x in results])))
            error_type = ",".join(list(set([x[6] for x in results])))
            azure_time_taken = max([x[7] for x in results])
            print("list comprehension completed check point")
            #self_calculated_token_size = sum([x[8] for x in results])
        return response,time_taken,token_count,total_cost,model_used,error,error_type,azure_time_taken    
    
    def split_func(self,code):
        #code = self.code_clean(code)
        print("split function started check point")
        classes=code.split('\n')
        classlist=[]
        scriptlist=[]
        cla=''
        for i in range(len(classes)):
            #dividing classes
            if len(re.findall(r'Class\.create\(\)',classes[i]))>0:
                classlist.append(cla)
                cla=''
                cla+=classes[i]+'\n'
            else:
                cla+=classes[i]+'\n'
            if(i==len(classes)-1):
                classlist.append(cla)
                cla=''
        classlist.pop(0)
        final_classlist=[]
        for i in range(len(classlist)):   
            #counting number of functions in every class
            fu=re.findall(r':\s*function\s*\(',classlist[i])
            if(len(fu)>1):
                lines=classlist[i].split('\n')
                #getting all the script present before starting first function
                prefix=''
                ind=2
                for j in range(len(lines)):
                    if len(re.findall(r':\s*function\s*\(',lines[j]))>0:
                        ind=j
                        break
                    else:
                        prefix+='\n'+lines[j]
                    #not considering global variables
                temp_prefix=prefix.split('\n')
                prefix2=temp_prefix[1]+'\n'+temp_prefix[-1]
                class_name_line=temp_prefix[1].strip()
                suffix='    type: '+class_name_line.split(' ')[1]+'\n};'
                #exluding class defining code lines
                nlines=lines[ind:-2]
                func=[]
                temp=''
                br=0
                comment=False
                for j in range(len(nlines)):
                    if len(re.findall(r':\s*function\s*\(',nlines[j]))>0:
                        temp+='\n'+nlines[j]
                    if '{' in nlines[j]:
                        br+=nlines[j].count('{')
                        #print(nlines[j],end='\n\n')
                    if '}' in nlines[j]:
                        br-=nlines[j].count('}')
                    if br == 0 and '},' in nlines[j]:
                        if len(re.findall(r':\s*function\s*\(',nlines[j]))==0:
                            temp+='\n'+nlines[j]
                        #adding class defining code prior to function
                        temp=prefix2+temp+'\n'+suffix
                        # temp=temp+'\n'
                        #appending all functions snippets to list
                        func.append(temp)
                        temp=''
                    if len(temp)>0:
                        if len(re.findall(r':\s*function\s*\(',nlines[j]))>0:
                            continue
                        temp+='\n'+nlines[j]
                #replacing that paticular class string with list of function strings
                for script in func:
                    final_classlist.append(script)
            else:
                final_classlist.append(classlist[i])
        print("split function ended check point")
        return final_classlist

    def gpt35turbo_large_script_generate(self,code):
        token_count = self.num_tokens_from_string(code,"cl100k_base")
        no_list = int(np.ceil(token_count/3000))
        list_func = self.split_func(code)
        # using list comprehension 
        num_rec = int(np.ceil(len(list_func)/no_list))
        list_func_split = [list_func[i:i + num_rec] for i in range(0, len(list_func), num_rec)]
        final_list=[]
        for i in list_func_split:
            if self.num_tokens_from_string('\n'.join(i),"cl100k_base")>4000:
                token_count_s = self.num_tokens_from_string('\n'.join(i),"cl100k_base")
                no_list_s = int(np.ceil(token_count_s/3000))
                list_func_s = self.split_func('\n'.join(i))
                # using list comprehension 
                num_rec_s = int(np.ceil(len(list_func_s)/no_list_s))
                list_func_split_s = [list_func_s[i:i + num_rec_s] for i in range(0, len(list_func_s), num_rec_s)]
                for j in list_func_split_s:
                    final_list.append('\n'.join(j))
            else:
                final_list.append('\n'.join(i))
        print("final_list:" + str(len(final_list)))
        response,time_taken,token_count,total_cost,model_used,error,error_type,azure_time_taken = self.parallel_api_call(final_list)
        
        return response,time_taken,token_count,total_cost,model_used,error,error_type,azure_time_taken


    def gpt35turbo_langchain_generate(self, code):

        start_time = datetime.now()
        prompt_response = None
        total_cost = 0.0
        tokens_count = 0
        model_used = ""
        error_message = ""
        error_type = ""
        azure_start_time = 0.0
        azure_end_time = 0.0
        input_prompt_size=0
        matching_docs=[]
        if len(code) <= 5:
            response = None
            error = "length of source code is too short to generate a response"
            error_type = "not_enough_tokens"

        elif len(code) > 5:

            #code = self.code_clean(code)
            prompt_template = PromptTemplate.from_template(
            '''
            Task:
            write unit test cases in Jasmine Framework for below servicenow script, create various test scenarios using multiple data points

            Instructions:
            - understand the code snippet below and write unit test cases
            - consider every scenario for unit testing
            - only write code
            - no comments and explanations for the written code

            code snippet:
            ####

            "{code}"

            ####

            Expected Output Format:
            // Test case: Testing....
            <code>
            .
            .

            ''')
            print("prompt template check point")
            system_message = "Think of Yourself as a QA Engineer and tester. You will be provided with Javascript source code as input and you need to generate unit test cases in Jasmine framework as output "
           
            prompt = prompt_template.format(code = code)

            input_prompt_size = self.num_tokens_from_string(
                prompt, "cl100k_base")
            print("input prompt size: " + str(input_prompt_size))
            azure_start_time = datetime.now()
            print("started input size if else template check point")
            if input_prompt_size < 1000:
                model_used = 'gpt-35-turbo'

                retriever = self.db.as_retriever(
                    search_type="similarity_score_threshold", search_kwargs={
                        "score_threshold": 0.5, "k": 1})
                print("crossed retriever check point")
                matching_docs = retriever.get_relevant_documents(code)
                if len(matching_docs) == 0:
                    value = [{"role": "system", "content": quote(system_message)},
                             {"role": "user", "content": quote(prompt)}] 
                    chat_completion = self.client.chat.completions.create(
                        model=model_used,
                        messages=value,
                        temperature=0
                        )
                    print("chat completion check point")
                    #response_json = json.loads(json.dumps(chat_completion))
                    print("json loading check point")
                    prompt_response = chat_completion.choices[0].message.content #response_json['choices'][0]['message']['content']
                    #print(prompt_response)
                    tokens_count = chat_completion.usage.total_tokens
                    total_cost = (int(chat_completion.usage.prompt_tokens)/1000)*0.0005 + (int(chat_completion.usage.completion_tokens)/1000)*0.0015
                    total_cost = round(total_cost,4)
                    model = chat_completion.model
                    print("json parsing check point")
                    status = "Success"
                    status_code = "200"
                    error_message = ""
                else:
                    matching_docs = self.restructure_document_object(matching_docs)
                    examples_retreived = self.few_shot_prompting_template(matching_docs)
                    value = [{"role": "system", "content": quote(system_message)},
                             {"role": "system", "content": quote(examples_retreived)},
                             {"role": "user", "content": quote(prompt)}]

                    chat_completion = self.client.chat.completions.create(
                        model=model_used,
                        messages=value,
                        temperature=0
                        )
                    print("chat completion check point")
                    #response_json = json.loads(json.dumps(chat_completion))
                    print("json loading check point")
                    prompt_response = chat_completion.choices[0].message.content #response_json['choices'][0]['message']['content']
                    #print(prompt_response)
                    tokens_count = chat_completion.usage.total_tokens
                    total_cost = (int(chat_completion.usage.prompt_tokens)/1000)*0.0005 + (int(chat_completion.usage.completion_tokens)/1000)*0.0015
                    total_cost = round(total_cost,4)
                    model = chat_completion.model
                    print("json parsing check point")
                    status = "success"
                    status_code = "200"
                    error_message = ""


            elif input_prompt_size >= 1000 and input_prompt_size < 4000:
                model_used = 'gpt-35-turbo-16k'

                retriever = self.db.as_retriever(
                    search_type="similarity_score_threshold", search_kwargs={
                        "score_threshold": 0.5, "k": 1})
                matching_docs = retriever.get_relevant_documents(code)
                print("Retriever check point")
                if len(matching_docs) == 0:
                    value = [{"role": "system", "content": quote(system_message)},
                             {"role": "user", "content": quote(prompt)}] 
                    chat_completion= self.client.chat.completions.create(
                        model=model_used,
                        messages=value,
                        temperature=0
                        )
                    print("chat completion check point")
                    #response_json = json.loads(json.dumps(chat_completion))
                    print("json loading check point")
                    prompt_response = chat_completion.choices[0].message.content #response_json['choices'][0]['message']['content']
                    #print(prompt_response)
                    tokens_count = chat_completion.usage.total_tokens
                    total_cost = (int(chat_completion.usage.prompt_tokens)/1000)*0.0005 + (int(chat_completion.usage.completion_tokens)/1000)*0.0015
                    total_cost = round(total_cost,4)
                    model = chat_completion.model
                    print("json parsing check point")
                    status = "Success"
                    status_code = "200"
                    error_message = ""
                else:
                    matching_docs = self.restructure_document_object(matching_docs)
                    examples_retreived = self.few_shot_prompting_template(matching_docs)
                    value = [{"role": "system", "content": quote(system_message)},
                             {"role": "system", "content": quote(examples_retreived)},
                             {"role": "user", "content": quote(prompt)}]

                    chat_completion = self.client.chat.completions.create(
                        model=model_used,
                        messages=value,
                        temperature=0
                        )
                    #response_json = json.loads(json.dumps(chat_completion))
                    print("json loading check point")
                    prompt_response = chat_completion.choices[0].message.content #response_json['choices'][0]['message']['content']
                    #print(prompt_response)
                    tokens_count = chat_completion.usage.total_tokens
                    total_cost = (int(chat_completion.usage.prompt_tokens)/1000)*0.0005 + (int(chat_completion.usage.completion_tokens)/1000)*0.0015
                    total_cost = round(total_cost,4)
                    model = chat_completion.model
                    print("json parsing check point")
                    status = "Success"
                    status_code = "200"
                    error_message = ""
                    

        azure_end_time = datetime.now()

        end_time = datetime.now()
        azure_time_taken = round((azure_end_time - azure_start_time).total_seconds(),2)  # type: ignore
        time_taken = round((end_time - start_time).total_seconds(), 2)
        return prompt_response, time_taken, tokens_count, total_cost, model_used, error_message, error_type, azure_time_taken


    def gpt35turbo_dummy(self, code):
        start_time = datetime.now()
        response = '''
        //This is a dummy response
        describe('Unit Testing for getTableId', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the unique value of the table record when the table name is valid', function() {
                var tableName = 'sys_user';
                var result = unitTestGenrationUtil.getTableId(tableName);
                var expectedResult = '1234567890';
                expect(result).toEqual(expectedResult);
            });

            it('should return false when the table name is invalid', function() {
                var tableName = 'invalid_table';
                var result = unitTestGenrationUtil.getTableId(tableName);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for createUnitTestRecord', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return false when scriptIncludeObj, sourceCode, and documentRef are all null', function() {
                var scriptIncludeObj = null;
                var sourceCode = null;
                var documentRef = null;
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });

            it('should create a unit test record when scriptIncludeObj is not null', function() {
                var scriptIncludeObj = new GlideRecord('sys_script_include');
                scriptIncludeObj.get('1234567890');
                var sourceCode = null;
                var documentRef = null;
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                expect(result).toBeTruthy();
            });

            it('should create a unit test record when sourceCode is not null', function() {
                var scriptIncludeObj = null;
                var sourceCode = 'function test() { return true; }';
                var documentRef = '1234567890';
                var requestCategory = 'test';
                var result = unitTestGenrationUtil.createUnitTestRecord(scriptIncludeObj, sourceCode, documentRef, requestCategory);
                expect(result).toBeTruthy();
            });
        });

        describe('Unit Testing for extractFunctionLineNumbers', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return an array of function objects with startLine and endLine properties', function() {
                var code = 'function test1() {\n    return true;\n}\n\nfunction test2() {\n    return false;\n}';
                var result = unitTestGenrationUtil.extractFunctionLineNumbers(code);
                var expectedResult = [
                    { name: 'test1', startLine: 1, endLine: 3 },
                    { name: 'test2', startLine: 5, endLine: 7 }
                ];
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getFunctionStartLine', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the line number of the start of the function', function() {
                var lines = [
                    'function test1() {',
                    '    return true;',
                    '}',
                    '',
                    'function test2() {',
                    '    return false;',
                    '}'
                ];
                var index = 5;
                var result = unitTestGenrationUtil.getFunctionStartLine(lines, index);
                var expectedResult = 5;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getDeltaSourceCode', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the delta source code based on the uncovered lines', function() {
                var scriptIncludeObj = new GlideRecord('sys_script_include');
                scriptIncludeObj.get('1234567890');
                var result = unitTestGenrationUtil.getDeltaSourceCode(scriptIncludeObj);
                expect(result).toBeTruthy();
            });
        });

        describe('Unit Testing for isInRange', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return true if the number is within the range of any object in the jsonArray', function() {
                var jsonArray = [
                    { startLine: 1, endLine: 3 },
                    { startLine: 5, endLine: 7 }
                ];
                var number = 2;
                var result = unitTestGenrationUtil.isInRange(jsonArray, number);
                var expectedResult = true;
                expect(result).toEqual(expectedResult);
            });

            it('should return false if the number is not within the range of any object in the jsonArray', function() {
                var jsonArray = [
                    { startLine: 1, endLine: 3 },
                    { startLine: 5, endLine: 7 }
                ];
                var number = 4;
                var result = unitTestGenrationUtil.isInRange(jsonArray, number);
                var expectedResult = false;
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getExecutableLineNumbers', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return a comma-separated string of line numbers that are executable', function() {
                var code = 'function test1() {\n    return true;\n}\n\nfunction test2() {\n    return false;\n}';
                var result = unitTestGenrationUtil.getExecutableLineNumbers(code);
                var expectedResult = '1,2,4,5,6,7';
                expect(result).toEqual(expectedResult);
            });
        });

        describe('Unit Testing for getCodeCoverageRecord', function() {
            var unitTestGenrationUtil = new UnitTestGenrationUtil();

            it('should return the latest code coverage record for the given scriptIncludeId', function() {
                var scriptIncludeId = '1234567890';
                var result = unitTestGenrationUtil.getCodeCoverageRecord(scriptIncludeId);
                expect(result).toBeTruthy();
            });
        });
        '''
        end_time = datetime.now()
        time_taken = round((end_time - start_time).total_seconds(), 2)
        azure_time_taken = '0'
        tokens_count = '2346'
        total_cost = '0.00000001'
        self_calculated_token_size = '2346'
        model_used = 'gpt-35-turbo-dummy'
        error = ""
        error_type = ""
        return response, time_taken, tokens_count, total_cost, model_used, error, error_type, azure_time_taken
